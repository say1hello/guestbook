<?php

interface IController {}