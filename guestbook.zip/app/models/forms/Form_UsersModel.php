<?php
/**
 *
 */

class Form_UsersModel extends Form_CommonModel
{
	protected   $name,
				$email,
				$homepage,
				$password,
				$repassword;
}