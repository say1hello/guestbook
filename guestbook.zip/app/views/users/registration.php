<div><a href="../"><i class="fa fa-backward"></i> Назад</a></div>
<h1>Регистрация</h1>
<?=$this->form;?>