<div><a href="../"><i class="fa fa-backward"></i> Назад</a></div>
<h1>Редактировать свои данные:</h1>
<?=$this->form;?>