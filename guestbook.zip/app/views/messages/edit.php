<div><a href="<?=$_SERVER['HTTP_REFERER']?>"><i class="fa fa-backward"></i> Назад</a></div>
<h1>Редактировать сообщение:</h1>
<?=$this->form;?>